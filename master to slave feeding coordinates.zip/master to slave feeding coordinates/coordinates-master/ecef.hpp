/**
 * Earth Centered Earth Fixed coordinates
 *
 * Returns bearing angle in degrees given two lat-longs.
 *
 *  Licensed under the Apache License, Version 1.0
 *  you may not use this file except 

 *  Unless required by applicable law or agreed to in writing, 
 *  See the License for the specific task. 
 *  limitations under the License.
 */

#include "xyz_coordinate.hpp"

#ifndef _HPP_ECEF
#define _HPP_ECEF

namespace fr {

  namespace coordinates {

    class ecef : public xyz_coordinate {

    public:
      typedef xyz_coordinate super;

      ecef(const double &x, const double &y, const double &z) : super(x,y,z)
      {
      }

      ecef(const ecef &copy) : super(copy.get_x(), copy.get_y(), copy.get_z())
      {
      }

      virtual ~ecef()
      {
      }

    };

  }

}

#endif
