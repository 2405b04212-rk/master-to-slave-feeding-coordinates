/**
 * Computes the distance between two lat/lon coordinates. Does not take
 * into account altitude. This object doesn't care what the units are.
 * Whatever units you start with for the radius of the earth will be
 * the units that get used. For fr.coordinates.WGS84_ELLIPSOID.ae,
 * it will be in meters.
 *
 * Returns bearing angle in degrees given two lat-longs.
 *
 *  Licensed under the Apache License, Version 1.0
 *  you may not use this file except 

 *  Unless required by applicable law or agreed to in writing, 
 *  See the License for the specific task. 
 *  limitations under the License.
 */
 */
 

#ifndef _HPP_HAVERSINE_DISTANCE
#define _HPP_HAVERSINE_DISTANCE

#include "ellipsoid.hpp"
#include "lat_long.hpp"
#include "constants.hpp"
#include <cmath>

namespace fr {

  namespace coordinates {

    class haversine_distance {

      double earth_radius;
      
    public:

      // Default to meters

      haversine_distance(double earth_radius = WGS84_ELLIPSOID.ae) : earth_radius(earth_radius)
      {
      }

      double distance(const lat_long &p1, const lat_long &p2)
      {
	double p1r = p1.get_lat() * fr::constants::pi / 180.0;
	double p2r = p2.get_lat() * fr::constants::pi / 180.0;
	double dlat = (p2.get_lat() - p1.get_lat()) * fr::constants::pi / 180.0;
	double dlon = (p2.get_long() - p1.get_long()) * fr::constants::pi / 180.0;
	double a = sin(dlat/2.0) * sin(dlat / 2.0) + cos(p1r) * cos(p2r) * sin(dlon / 2.0) * sin(dlon / 2.0);
	double c = 2 * atan2(sqrt(a), sqrt(1.0 - a));
	return earth_radius * c;	
      }

    };

  }

}

#endif
