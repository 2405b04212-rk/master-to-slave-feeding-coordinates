/**
 * Add your ellipsoid parameters here, if you need something
 * other than WGS_84
 *
/**
 * Returns bearing angle in degrees given two lat-longs.
 *
 *  Licensed under the Apache License, Version 1.0
 *  you may not use this file except 

 *  Unless required by applicable law or agreed to in writing, 
 *  See the License for the specific task. 
 *  limitations under the License.
 */

#ifndef _HPP_ELLIPSOID
#define _HPP_ELLIPSOID

namespace fr {

  namespace coordinates {

    struct ellipsoid_parameters {
      double ae;
      double ee;

      ellipsoid_parameters(const double &ae, const double &ee) : ae(ae), ee(ee)
      {
      }
    };

    const ellipsoid_parameters WGS84_ELLIPSOID(6378137.0, 0.00669437999014);

  }
}

#endif
