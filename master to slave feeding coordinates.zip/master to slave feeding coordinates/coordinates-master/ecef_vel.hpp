/**
 * Six point version of ecef, with velocities. This doesn't inherit
 * from ecef because there's nothing actually unique in ecef.
 *
 * Returns bearing angle in degrees given two lat-longs.
 *
 *  Licensed under the Apache License, Version 1.0
 *  you may not use this file except 

 *  Unless required by applicable law or agreed to in writing, 
 *  See the License for the specific task. 
 *  limitations under the License.
 */

#include "ecef.hpp"
#include "xyz_velocity.hpp"

#ifndef _HPP_ECEF_VEL
#define _HPP_ECEF_VEL

namespace fr {

  namespace coordinates {

    class ecef_vel : public xyz_velocity {
    public:
      typedef xyz_velocity super;

      ecef_vel(const double &x, const double &y, const double &z, const double &dx, const double &dy, const double &dz) : xyz_velocity(x,y,z,dx,dy,dz)
      {
      }

      ecef_vel(const ecef_vel &copy) : xyz_velocity(copy.x, copy.y, copy.z, copy.dx, copy.dy, copy.dz) 
      {
	
      }

      ecef_vel() : xyz_velocity(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
      {
      }

      virtual ~ecef_vel()
      {
      }

    };

  }
}

#endif
