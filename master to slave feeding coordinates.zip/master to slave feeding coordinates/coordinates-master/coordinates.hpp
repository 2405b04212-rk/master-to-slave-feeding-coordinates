/**
 * Returns bearing angle in degrees given two lat-longs.
 *
 *  Licensed under the Apache License, Version 1.0
 *  you may not use this file except 

 *  Unless required by applicable law or agreed to in writing, 
 *  See the License for the specific task. 
 *  limitations under the License.
 */

#ifndef _HPP_COORDINATES
#define _HPP_COORDINATES

#include "constants.hpp"
#include "conversion_matrices.hpp"
#include "ecef.hpp"
#include "ecef_vel.hpp"
#include "ellipsoid.hpp"
#include "lat_long.hpp"
#include "tod_eci.hpp"
#include "tod_eci_vel.hpp"
#include "xyz_coordinate.hpp"
#include "xyz_velocity.hpp"
#include "converts.hpp"

#endif
