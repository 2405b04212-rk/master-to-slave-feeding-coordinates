 /**
 * Returns bearing angle in degrees given two lat-longs.
 *
 *  Licensed under the Apache License, Version 1.0
 *  you may not use this file except 

 *  Unless required by applicable law or agreed to in writing, 
 *  See the License for the specific task. 
 *  limitations under the License.
 */

#include <math.h>

#ifndef _HPP_CONSTANTS
#define _HPP_CONSTANTS

namespace fr {

  namespace constants {
    const double pi = atan2(1.0, 1.0) * 4.0;
    const double secs_per_ut1_day = 86400.0;
    const double ut1_sideral_day_ratio = 1.002737811906;
  };

};

#endif
